/**
 * script.js - Interactive logic for CityHub Portal
 * Points 6, 7, 8, 9, 10
 */

// Debugging Point 10: Initial Log
console.log("CityHub Script initialized...");

// 1. Storage Logic (Point 8)
document.addEventListener('DOMContentLoaded', () => {
    const savedEvent = localStorage.getItem('preferredEvent');
    if (savedEvent) {
        document.getElementById('eventType').value = savedEvent;
        updateFeeDisplay(savedEvent);
        console.log("Retrieved preference from localStorage:", savedEvent);
    }
});

// 2. Event Handling Logic (Point 6)

// On Blur - Phone validation
const phoneInput = document.getElementById('phone');
phoneInput.onblur = () => {
    const phonePattern = /^\d{3}-\d{3}-\d{4}$/;
    if (phoneInput.value && !phonePattern.test(phoneInput.value)) {
        alert("Please enter a valid phone number (123-456-7890)");
        phoneInput.style.borderColor = "#e63946";
    } else {
        phoneInput.style.borderColor = "#ccc";
    }
    console.log("Phone field blurred. Value:", phoneInput.value);
};

// On Change - Dropdown
const eventSelect = document.getElementById('eventType');
eventSelect.onchange = (e) => {
    const val = e.target.value;
    updateFeeDisplay(val);
    
    // Save to localStorage (Point 8)
    localStorage.setItem('preferredEvent', val);
    console.log("Saved selection to localStorage:", val);
};

function updateFeeDisplay(val) {
    const feeDisplay = document.getElementById('feeDisplay');
    const fees = {
        'jazz': '$25.00',
        'market': 'Free',
        'run': '$15.00',
        '': ''
    };
    if (val) {
        feeDisplay.textContent = `Event Fee: ${fees[val]}`;
    } else {
        feeDisplay.textContent = '';
    }
}

// On Click - Submit Button Confirmation
const regForm = document.getElementById('regForm');
regForm.onsubmit = (e) => {
    e.preventDefault();
    const output = document.getElementById('confirmMessage');
    const name = document.getElementById('name').value;
    output.textContent = `✅ Thank you, ${name}! Your registration for ${eventSelect.value} has been submitted.`;
    output.style.color = "#457b9d";
    alert("Registration Successful!");
    console.log("Form submitted by:", name);
};

// On DblClick - Image Enlarge
const galleryImgs = document.querySelectorAll('.gallery-img');
galleryImgs.forEach(img => {
    img.ondblclick = () => {
        if (img.style.transform === "scale(1.5)") {
            img.style.transform = "scale(1)";
            img.style.zIndex = "1";
        } else {
            img.style.transform = "scale(1.5)";
            img.style.zIndex = "10";
            img.style.position = "relative";
        }
        console.log("Image double-clicked:", img.title);
    };
});

// Keyboard Events - Character Count
const messageArea = document.getElementById('message');
const charCountDisplay = document.getElementById('charCount');
messageArea.onkeyup = (e) => {
    const count = messageArea.value.length;
    charCountDisplay.textContent = `${count} characters entered`;
    console.log("Keyup in message area. Current length:", count);
};

// 3. Media Events (Point 7)
function videoReady() {
    const msg = document.getElementById('videoMessage');
    msg.style.display = 'block';
    console.log("Video metadata loaded and ready to play.");
}

// Before Unload Warning
window.onbeforeunload = (e) => {
    // Only warn if they've typed something
    if (document.getElementById('name').value || document.getElementById('email').value) {
        return "You have unsaved changes. Are you sure you want to leave?";
    }
};

// 4. Geolocation (Point 9)
const findBtn = document.getElementById('findEventsBtn');
const locationDisplay = document.getElementById('locationDisplay');

findBtn.onclick = () => {
    if ("geolocation" in navigator) {
        locationDisplay.textContent = "Locating...";
        
        const options = {
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0
        };

        navigator.geolocation.getCurrentPosition(
            (position) => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;
                locationDisplay.textContent = `📍 Success! Your coordinates: Lat ${lat.toFixed(4)}, Lon ${lon.toFixed(4)}`;
                locationDisplay.style.color = "#457b9d";
                console.log("Geolocation success:", lat, lon);
            },
            (error) => {
                let errorMsg = "";
                switch(error.code) {
                    case error.PERMISSION_DENIED:
                        errorMsg = "User denied the request for Geolocation.";
                        break;
                    case error.POSITION_UNAVAILABLE:
                        errorMsg = "Location information is unavailable.";
                        break;
                    case error.TIMEOUT:
                        errorMsg = "The request to get user location timed out.";
                        break;
                    default:
                        errorMsg = "An unknown error occurred.";
                        break;
                }
                locationDisplay.textContent = `❌ Error: ${errorMsg}`;
                locationDisplay.style.color = "#e63946";
                console.error("Geolocation error:", errorMsg);
            },
            options
        );
    } else {
        locationDisplay.textContent = "Geolocation is not supported by this browser.";
    }
};

// 5. Clear Preferences (Point 8)
document.getElementById('clearPrefsBtn').onclick = () => {
    localStorage.clear();
    sessionStorage.clear();
    document.getElementById('regForm').reset();
    document.getElementById('feeDisplay').textContent = '';
    alert("Preferences cleared!");
    console.log("localStorage and sessionStorage cleared.");
};

// Debugging Point 10: Breakpoint simulation
function simulateProcess() {
    let x = 10;
    let y = 20;
    let z = x + y;
    // Inspect z here in DevTools if you add a breakpoint
    console.log("Process simulation result:", z);
}
simulateProcess();
