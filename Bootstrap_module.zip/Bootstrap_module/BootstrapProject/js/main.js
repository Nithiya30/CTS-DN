// main.js - Custom Interactions

document.addEventListener('DOMContentLoaded', function() {
    console.log('Bootstrap Showcase Pro - Ready');

    // Add tooltips if needed (Bootstrap requirement for initialization)
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Smooth Scrolling for nav links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if(targetId === '#') return;
            
            document.querySelector(targetId).scrollIntoView({
                behavior: 'smooth'
            });

            // Close sidebar on mobile after click
            const sidebar = document.getElementById('sidebarMenu');
            if (sidebar.classList.contains('show')) {
                const bsCollapse = new bootstrap.Collapse(sidebar);
                bsCollapse.hide();
            }
        });
    });
});
