/* ==========================================================================
   JAVASCRIPT IMPLEMENTATION - LOCAL COMMUNITY EVENT PORTAL
   ========================================================================== */

// 1. JS Setup
// Console log on load as required
console.log("Welcome to the Community Portal");

// Array of loaded Event objects
let eventsList = [];

// Session booking counter closure instance
const sessionCounter = createRegistrationCounter();

// Page load alert & initial startup
window.addEventListener('DOMContentLoaded', () => {
  // Requirement: Page load alert
  alert("Welcome to the Smart City Community Portal! Discover what's happening around you today.");
  
  // Load preferences from Storage
  initializePreferences();
  
  // Asynchronously load events
  loadEventsAsync();
  
  // Initialise session count
  updateSessionCounterUI();
  
  // Set up character counter for feedback
  setupFeedbackCounter();

  // Set up Form beforeunload handler
  setupUnloadWarning();
});

/* ==========================================================================
   2. DATA TYPES, OPERATORS, & MODERN JS
   ========================================================================== */
// Declaring configuration constants (Requirement: const for event details)
const DEFAULT_CURRENCY = 'USD';
const MOCK_API_DELAY = 1200;

// Requirement: Default parameters, spread operator, destructuring
function formatEventBadge({ category = 'General', price = 0 } = {}) {
  // Requirement: Template literals
  const priceText = price === 0 ? 'FREE' : `$${price.toFixed(2)}`;
  return `[${category.toUpperCase()} - ${priceText}]`;
}

/* ==========================================================================
   3. OBJECTS, PROTOTYPES, & ARRAYS
   ========================================================================== */
// Requirement: Event class/prototype
function CommunityEvent(id, title, category, date, location, price, seatsAvailable, totalSeats, description, image) {
  this.id = id;
  this.title = title;
  this.category = category;
  this.date = date; // Format: YYYY-MM-DD
  this.location = location;
  this.price = price;
  this.seatsAvailable = seatsAvailable; // let variables (can change)
  this.totalSeats = totalSeats;
  this.description = description;
  this.image = image;
  this.registeredUsers = []; // Track registered user names
}

// Add method on Prototype
CommunityEvent.prototype.checkAvailability = function() {
  return this.seatsAvailable > 0;
};

// Prototype method using Object.entries() to print diagnostic details
CommunityEvent.prototype.logDiagnostics = function() {
  console.log(`--- Event Diagnostic for: ${this.title} ---`);
  // Requirement: Object.entries()
  for (const [key, value] of Object.entries(this)) {
    if (typeof value !== 'function') {
      console.log(`${key}: ${JSON.stringify(value)}`);
    }
  }
};

// Requirement: Closure for registration count
function createRegistrationCounter() {
  let count = 0; // Private state
  return {
    increment: function() {
      count++;
      return count;
    },
    decrement: function() {
      if (count > 0) count--;
      return count;
    },
    getCount: function() {
      return count;
    }
  };
}

/* ==========================================================================
   4. CORE FUNCTIONS
   ========================================================================== */
// Adds event to list (Requirement: addEvent)
function addEvent(eventObj) {
  eventsList.push(eventObj);
}

// Requirement: callback filtering
function filterEventsByCategory(category, callback) {
  const result = eventsList.filter(event => {
    if (category === 'All') return true;
    return event.category.toLowerCase() === category.toLowerCase();
  });
  
  if (callback && typeof callback === 'function') {
    return callback(result);
  }
  return result;
}

// Demonstration of Arrays filter() and map() for Music category (Requirement: music event filter)
function displayMusicEventsSummary() {
  // Filter for Music events
  const musicEvents = eventsList.filter(e => e.category.toLowerCase() === 'music');
  
  // Format details using map()
  const titles = musicEvents.map(e => `${e.title} at ${e.location}`);
  console.log("Filtered Music Events (Array.map):", titles);
}

/* ==========================================================================
   5. ASYNC JAVASCRIPT & FETCH
   ========================================================================== */
// Intercepting fetch calls globally to simulate a local REST API POST request
const originalFetch = window.fetch;
window.fetch = async function(url, options) {
  if (url === '/api/register' && options && options.method === 'POST') {
    const payload = JSON.parse(options.body);
    // Requirement: Debugging logs (fetch payload logs)
    console.log("Fetch POST call initiated. Destination: /api/register. Payload: ", payload);
    
    return new Promise((resolve, reject) => {
      // Requirement: setTimeout
      setTimeout(() => {
        // If Name contains "error", simulate an API error
        if (payload.userName.toLowerCase().includes('error')) {
          reject(new Error("Simulated API Error: Database rejection."));
        } else {
          resolve({
            ok: true,
            status: 201,
            json: async () => ({
              success: true,
              message: `Registration successful for ${payload.userName}!`,
              bookingCode: `SMART-${Math.floor(Math.random() * 90000) + 10000}`
            })
          });
        }
      }, MOCK_API_DELAY);
    });
  }
  return originalFetch.apply(this, arguments);
};

// Async function to load events from JSON file (Requirement: async await, then, catch)
async function loadEventsAsync() {
  const spinner = document.getElementById('loadingSpinner');
  const grid = document.getElementById('eventsGrid');
  
  // Show Loading Spinner (display: flex)
  spinner.classList.remove('display-none');
  grid.innerHTML = '';

  // Use fetch to retrieve JSON data
  fetch('events.json')
    .then(response => {
      if (!response.ok) {
        throw new Error("HTTP error loading events.json: " + response.status);
      }
      return response.json();
    })
    .then(data => {
      // Process items into class instances
      // Requirement: Modern JS destructuring, let/const, spread operator
      data.forEach(item => {
        const { id, title, category, date, location, price, seatsAvailable, totalSeats, description, image } = item;
        const newEvt = new CommunityEvent(id, title, category, date, location, price, seatsAvailable, totalSeats, description, image);
        addEvent(newEvt);
      });
      
      console.log("Events successfully parsed into memory array. Length:", eventsList.length);
      
      // Initial render based on preferences
      renderEventsGrid(eventsList);
      
      // Perform Music array filter demo
      displayMusicEventsSummary();
      
      // Log diagnostic details for the first event
      if (eventsList[0]) eventsList[0].logDiagnostics();
    })
    .catch(error => {
      console.error("Failed to load events asynchronously: ", error);
      grid.innerHTML = `<p class="seats-full" style="text-align:center; width:100%;">Failed to load community events. Please try again later. Error: ${error.message}</p>`;
    })
    .finally(() => {
      // Hide loading spinner
      spinner.classList.add('display-none');
    });
}

/* ==========================================================================
   6. DOM MANIPULATION & INTERACTION
   ========================================================================== */
// Renders the list of events into the event cards grid
function renderEventsGrid(items) {
  const grid = document.getElementById('eventsGrid');
  grid.innerHTML = '';
  
  if (items.length === 0) {
    grid.innerHTML = '<p style="text-align:center; grid-column: 1/-1; color: #94a3b8;">No matching events found.</p>';
    return;
  }
  
  // Requirement: forEach loop to output
  items.forEach(event => {
    // Create card container element (Requirement: createElement, querySelector, appendChild)
    const card = document.createElement('article');
    card.className = 'eventCard';
    card.setAttribute('data-id', event.id);
    
    // Check seat state (Requirement: if/else conditional check)
    let seatHtml = '';
    let btnHtml = '';
    
    if (event.seatsAvailable <= 0) {
      seatHtml = `<span class="seats-counter seats-full">FULLY BOOKED</span>`;
      btnHtml = `<button class="btn btn-secondary btn-sm" disabled>Full</button>`;
    } else {
      seatHtml = `<span class="seats-counter seats-avail">${event.seatsAvailable} of ${event.totalSeats} seats left</span>`;
      
      // Check if user is registered in this session
      const isRegistered = event.registeredUsers.includes("YOU");
      if (isRegistered) {
        btnHtml = `<button class="btn btn-danger btn-sm" onclick="toggleRegistration(${event.id})">Cancel</button>`;
      } else {
        btnHtml = `<button class="btn btn-primary btn-sm" onclick="toggleRegistration(${event.id})">Register</button>`;
      }
    }
    
    // Build templates (Requirement: template literals, spread operator demonstration)
    const badgeText = formatEventBadge({ ...event }); // uses spread operator to pass properties
    
    card.innerHTML = `
      <img src="${event.image}" alt="${event.title}" class="event-img">
      <div class="event-body">
        <span class="event-cat">${badgeText}</span>
        <h3>${event.title}</h3>
        <p>${event.description}</p>
        <ul class="event-details">
          <li><strong>📅 Date:</strong> ${event.date}</li>
          <li><strong>📍 Location:</strong> ${event.location}</li>
        </ul>
        <div class="event-actions">
          ${seatHtml}
          ${btnHtml}
        </div>
      </div>
    `;
    
    grid.appendChild(card);
  });
}

// User action handler triggered on card registration clicks (Requirement: ++ and -- seat updates)
function toggleRegistration(eventId) {
  // Find event in array
  const event = eventsList.find(e => e.id === eventId);
  if (!event) return;
  
  const index = event.registeredUsers.indexOf("YOU");
  
  if (index > -1) {
    // Cancel reservation
    event.registeredUsers.splice(index, 1);
    event.seatsAvailable++; // Operator: ++ increment seat availability
    sessionCounter.decrement(); // Closure decremented
    console.log(`Cancelled registration for event: ${event.title}. Remainder seats: ${event.seatsAvailable}`);
  } else {
    // Register reservation
    if (event.seatsAvailable > 0) {
      event.registeredUsers.push("YOU");
      event.seatsAvailable--; // Operator: -- decrement seat availability
      sessionCounter.increment(); // Closure incremented
      console.log(`Registered for event: ${event.title}. Remaining seats: ${event.seatsAvailable}`);
      
      // Pre-fill Event Dropdown in form to enhance UX
      const optionVal = getDropdownValueByEventName(event.title);
      if (optionVal) {
        document.getElementById('eventType').value = optionVal;
        displayEventFee();
      }
    }
  }
  
  // Refresh UI grids and session values
  renderFilteredList();
  updateSessionCounterUI();
}

// Maps standard titles to dropdown values
function getDropdownValueByEventName(name) {
  if (name.includes("Hackathon")) return "Tech Hackathon";
  if (name.includes("Jazz")) return "Jazz Concert";
  if (name.includes("Clean-up")) return "Green Clean-up";
  if (name.includes("Artisan")) return "Art Fair";
  if (name.includes("Fun Run")) return "Charity Run";
  if (name.includes("Food")) return "Food Festival";
  return "";
}

// Re-renders grid applying filter and search parameters
function renderFilteredList() {
  const cat = document.getElementById('categoryFilter').value;
  const query = document.getElementById('quickSearch').value.toLowerCase();
  
  let list = eventsList;
  
  // Apply category filtering
  if (cat !== 'All') {
    list = filterEventsByCategory(cat);
  }
  
  // Apply search criteria
  if (query) {
    list = list.filter(e => 
      e.title.toLowerCase().includes(query) || 
      e.description.toLowerCase().includes(query)
    );
  }
  
  renderEventsGrid(list);
}

// Updates session count badge
function updateSessionCounterUI() {
  document.getElementById('sessCount').innerText = sessionCounter.getCount();
}

/* ==========================================================================
   7. INPUT EVENTS, FILTERS, SEARCH
   ========================================================================== */
// Bind filter and search listeners
document.addEventListener('DOMContentLoaded', () => {
  // Search text box keydown & keyup binding (Requirement: keydown quick search)
  const searchInput = document.getElementById('quickSearch');
  searchInput.addEventListener('keyup', () => {
    renderFilteredList();
  });
  
  // Dropdown onchange binding
  const catFilter = document.getElementById('categoryFilter');
  catFilter.addEventListener('change', () => {
    renderFilteredList();
  });
});

/* ==========================================================================
   8. FORM VALIDATION & AJAX POST SUBMISSION
   ========================================================================== */
// Phone Validation blur handler (Requirement: onblur phone validation)
function validatePhoneField() {
  const phoneInput = document.getElementById('userPhone');
  const errorDiv = document.getElementById('phoneError');
  const value = phoneInput.value.replace(/\D/g, ''); // Strip non-digits
  
  if (value.length !== 10) {
    errorDiv.style.display = 'block';
    phoneInput.classList.add('border-danger');
    return false;
  } else {
    errorDiv.style.display = 'none';
    phoneInput.classList.remove('border-danger');
    phoneInput.value = value; // Reformat text to standard digit block
    return true;
  }
}

// Select change fee handler (Requirement: onchange fee display)
function displayEventFee() {
  const select = document.getElementById('eventType');
  const display = document.getElementById('feeDisplay');
  const value = select.value;
  
  let fee = '';
  switch (value) {
    case 'Tech Hackathon':
    case 'Green Clean-up':
      fee = 'Free Event ($0.00)';
      break;
    case 'Jazz Concert':
      fee = 'Jazz Entry: $15.00';
      break;
    case 'Art Fair':
      fee = 'Art Fair Ticket: $5.00';
      break;
    case 'Charity Run':
      fee = '5K Marathon: $25.00';
      break;
    case 'Food Festival':
      fee = 'Food Festival Ticket: $10.00';
      break;
    default:
      fee = 'Select an event to view entry fee.';
  }
  
  display.innerText = fee;
}

// Click Submit confirmation popup (Requirement: onclick submit confirmation)
function confirmSubmit() {
  // This triggers standard browser confirmation before compiling payload
  return confirm("Are you sure you want to submit this registration request?");
}

// Registration Form Submission Handler (Requirement: form.elements, preventDefault, try catch)
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('regForm');
  
  form.addEventListener('submit', async (e) => {
    e.preventDefault(); // Prevent standard page reloads
    
    // Perform standard form field checks
    let isValid = true;
    const nameVal = form.elements['userName'].value.trim();
    const emailVal = form.elements['userEmail'].value.trim();
    const dateVal = form.elements['eventDate'].value;
    const typeVal = form.elements['eventType'].value;
    
    // Simple checks (Inline validation style)
    if (!nameVal) {
      document.getElementById('nameError').style.display = 'block';
      isValid = false;
    } else {
      document.getElementById('nameError').style.display = 'none';
    }
    
    if (!emailVal || !emailVal.includes('@')) {
      document.getElementById('emailError').style.display = 'block';
      isValid = false;
    } else {
      document.getElementById('emailError').style.display = 'none';
    }
    
    if (!validatePhoneField()) {
      isValid = false;
    }
    
    if (!dateVal) {
      document.getElementById('dateError').style.display = 'block';
      isValid = false;
    } else {
      document.getElementById('dateError').style.display = 'none';
    }
    
    if (!isValid) {
      console.warn("Form validation checks failed. Registration halted.");
      return; // Stop submission
    }
    
    // Gather values to construct payload (Requirement: form logs, console logs)
    const payload = {
      userName: nameVal,
      userEmail: emailVal,
      userPhone: form.elements['userPhone'].value.trim(),
      eventDate: dateVal,
      eventType: typeVal,
      userMessage: form.elements['userMessage'].value.trim()
    };
    
    console.log("Registration form verification completed. Submitting fields:", payload);
    
    // Display submission state (using jQuery helper hooks)
    const alertBox = $('#submitAlert');
    alertBox.removeClass('visibility-hidden alert-success alert-danger').addClass('alert-success');
    $('#alertIcon').text('⏳');
    $('#alertText').text('Processing registration request. Please wait...');
    alertBox.css('visibility', 'visible').hide().fadeIn(300);
    
    try {
      // Simulate API registration call (Requirement: Fetch POST, catch, success, failure)
      const response = await fetch('/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });
      
      if (!response.ok) {
        throw new Error(`Server returned error status: ${response.status}`);
      }
      
      const resData = await response.json();
      console.log("API Response details received:", resData);
      
      // If success, update alerts and counters
      $('#alertIcon').text('✅');
      $('#alertText').text(`Registration confirmed! Booking Code: ${resData.bookingCode}`);
      alertBox.removeClass('alert-danger').addClass('alert-success');
      
      // Update closure booking value
      sessionCounter.increment();
      updateSessionCounterUI();
      
      // Form reset
      form.reset();
      document.getElementById('feeDisplay').innerText = 'Select an event to view entry fee.';
      
      // Automatically fade out after 6 seconds
      setTimeout(() => {
        alertBox.fadeOut(400);
      }, 6000);
      
    } catch (err) {
      // Error handling (Requirement: failure message)
      console.error("AJAX registration request failed: ", err);
      $('#alertIcon').text('❌');
      $('#alertText').text(`Registration failed: ${err.message}`);
      alertBox.removeClass('alert-success').addClass('alert-danger');
    }
  });
});

/* ==========================================================================
   9. FEEDBACK & CHARACTER COUNTER
   ========================================================================== */
// Keyboard character counter implementation (Requirement: keyboard character counter)
function setupFeedbackCounter() {
  const textarea = document.getElementById('feedbackText');
  const counterSpan = document.getElementById('charCount');
  
  if (!textarea || !counterSpan) return;
  
  const updateCount = () => {
    const len = textarea.value.length;
    counterSpan.innerText = len;
    
    if (len >= 140) {
      counterSpan.style.color = '#ef4444'; // Red flag for max limits
    } else {
      counterSpan.style.color = '#38bdf8';
    }
  };
  
  textarea.addEventListener('keydown', updateCount);
  textarea.addEventListener('keyup', updateCount);
  textarea.addEventListener('input', updateCount);
}

// Feedback submission simulation (uses jQuery fade effects)
document.addEventListener('DOMContentLoaded', () => {
  $('#submitFeedbackBtn').click(function() {
    const text = $('#feedbackText').val().trim();
    if (!text) {
      alert("Please enter a short comment before submitting.");
      return;
    }
    
    // Clear textarea
    $('#feedbackText').val('');
    $('#charCount').text('0');
    
    // Success alerts via jQuery Fade Effects
    const feedbackBox = $('#feedbackAlert');
    feedbackBox.removeClass('visibility-hidden');
    feedbackBox.hide().fadeIn(300);
    
    setTimeout(() => {
      feedbackBox.fadeOut(400);
    }, 4000);
  });
});

/* ==========================================================================
   10. INTERACTIVE VIDEO EVENTS
   ========================================================================== */
// Video canplay event handler (Requirement: oncanplay message)
function videoReadyAlert() {
  const statusSpan = document.getElementById('videoStatus');
  if (statusSpan) {
    statusSpan.innerText = "🎬 Video ready to play";
    statusSpan.classList.remove('opacity-hidden');
    statusSpan.classList.add('opacity-visible');
    
    // Console notice
    console.log("Promo video file loading completes. Ready for playback.");
  }
}

/* ==========================================================================
   11. BEFORE UNLOAD LISTENER
   ========================================================================== */
// Warn before leaving unfinished form (Requirement: onbeforeunload)
function setupUnloadWarning() {
  window.onbeforeunload = function(e) {
    const name = document.getElementById('userName').value;
    const email = document.getElementById('userEmail').value;
    const phone = document.getElementById('userPhone').value;
    
    // Check if user has partially typed details
    if (name || email || phone) {
      const msg = "You have unsaved event registration details. If you leave, these details will be lost.";
      e.returnValue = msg; // Standard confirmation prompt
      return msg;
    }
  };
}

/* ==========================================================================
   12. WEB STORAGE PREFERENCES
   ========================================================================== */
// Save category preference (Requirement: localStorage / sessionStorage)
function initializePreferences() {
  const saveBtn = document.getElementById('savePrefBtn');
  const clearBtn = document.getElementById('clearPrefBtn');
  const filterSelect = document.getElementById('categoryFilter');
  const display = document.getElementById('preferenceDisplay');
  
  // Check localStorage for saved category
  const savedCategory = localStorage.getItem('preferredCategory');
  
  if (savedCategory) {
    console.log("Auto-loaded stored category preference:", savedCategory);
    filterSelect.value = savedCategory;
    display.innerText = `Preferred theme active: ${savedCategory}`;
    display.style.display = 'block';
    
    // Set sessionStorage to track loaded state in current session tab
    sessionStorage.setItem('loadedPreferenceThisSession', 'true');
  }

  // Save click binding
  saveBtn.addEventListener('click', () => {
    const selectedVal = filterSelect.value;
    localStorage.setItem('preferredCategory', selectedVal);
    
    display.innerText = `Preference saved: ${selectedVal}. Refresh to see auto-load action.`;
    display.style.display = 'block';
    
    console.log(`Preferences cached. preferredCategory: ${selectedVal}`);
  });
  
  // Clear click binding (Requirement: Clear Preferences button)
  clearBtn.addEventListener('click', () => {
    localStorage.removeItem('preferredCategory');
    sessionStorage.removeItem('loadedPreferenceThisSession');
    
    filterSelect.value = 'All';
    display.innerText = '';
    display.style.display = 'none';
    
    console.log("Cached storage preferences cleared.");
    renderFilteredList();
  });
}

/* ==========================================================================
   13. GEOLOCATION AND SERVICE FINDER
   ========================================================================== */
// Get geographic position of local users (Requirement: Geolocation)
document.addEventListener('DOMContentLoaded', () => {
  const geoBtn = document.getElementById('findNearbyBtn');
  const geoDisplay = document.getElementById('geoDisplay');
  const geoError = document.getElementById('geoError');
  
  geoBtn.addEventListener('click', () => {
    // Reset displays
    geoDisplay.classList.add('display-none');
    geoError.classList.add('display-none');
    geoBtn.innerText = "Searching Coordinates...";
    
    // Check compatibility
    if (!navigator.geolocation) {
      handleGeoError({ code: 0, message: "Geolocation services are not supported by this browser." });
      return;
    }
    
    // Query coords with high accuracy and 10s timeout
    const options = {
      enableHighAccuracy: true, // Requirement: high accuracy
      timeout: 10000,          // Requirement: timeout
      maximumAge: 0
    };
    
    navigator.geolocation.getCurrentPosition(handleGeoSuccess, handleGeoError, options);
  });
});

// Success callback (latitude and longitude displayed)
function handleGeoSuccess(position) {
  const geoBtn = document.getElementById('findNearbyBtn');
  const geoDisplay = document.getElementById('geoDisplay');
  const latSpan = document.getElementById('latText');
  const lonSpan = document.getElementById('lonText');
  const resultsDiv = document.getElementById('geoResults');
  
  geoBtn.innerText = "📍 Update Location";
  geoDisplay.classList.remove('display-none');
  
  // Coords mapping
  const lat = position.coords.latitude;
  const lon = position.coords.longitude;
  
  latSpan.innerText = lat.toFixed(6);
  lonSpan.innerText = lon.toFixed(6);
  
  console.log(`Geolocation lookup successful. Latitude: ${lat}, Longitude: ${lon}`);
  
  // Insert nearby mockup recommendations based on coordinate markers
  resultsDiv.innerHTML = `
    <h4>Closest Intelligent Smart Spots:</h4>
    <div class="geo-item">
      <strong>Community Innovation Hub:</strong> Located 0.8 miles away (Route A Autonomous Shuttle station)
    </div>
    <div class="geo-item">
      <strong>Municipal Library Charging Kiosk:</strong> Located 1.4 miles away (Eco-Park block)
    </div>
  `;
}

// Error callback mapping all 4 required handling branches
function handleGeoError(error) {
  const geoBtn = document.getElementById('findNearbyBtn');
  const geoError = document.getElementById('geoError');
  geoBtn.innerText = "📍 Find Nearby Event Hubs";
  geoError.classList.remove('display-none');
  
  let errorMsg = '';
  switch (error.code) {
    case error.PERMISSION_DENIED: // Requirement: denied permission
      errorMsg = "Coordinates Request Denied: Access to device location was blocked. Please enable geolocation permissions in your browser settings.";
      break;
    case error.POSITION_UNAVAILABLE: // Requirement: unavailable location
      errorMsg = "Location Unavailable: Geographic position information is not obtainable on this network/device.";
      break;
    case error.TIMEOUT: // Requirement: timeout
      errorMsg = "Location Query Timeout: The request to obtain device coordinates timed out before receiving data.";
      break;
    default:
      errorMsg = `GPS Error: ${error.message || "An unknown error occurred during coordinate extraction."}`;
  }
  
  console.error("Geolocation service error:", errorMsg);
  geoError.innerText = errorMsg;
}

/* ==========================================================================
   14. GALLERY DOUBLE CLICK ZOOM (LIGHTBOX EFFECT)
   ========================================================================== */
// Requirement: ondblclick enlarge image
function zoomImage(imgElement) {
  const modal = document.getElementById('lightboxModal');
  const modalImg = document.getElementById('lightboxImg');
  const captionText = document.getElementById('lightboxCaption');
  
  modal.style.display = "flex";
  modalImg.src = imgElement.src;
  captionText.innerHTML = imgElement.title || imgElement.alt;
  
  console.log(`Gallery zoom triggered (ondblclick) for: ${imgElement.title}`);
}

function closeZoom() {
  document.getElementById('lightboxModal').style.display = "none";
}
