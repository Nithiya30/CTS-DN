/**
 * Local Community Event Portal - Interactive JavaScript
 * Implements form validation, event handling, geolocation, state storage, and dynamic elements.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Initialize responsive menu toggler
  initMobileMenu();

  // Load Saved Preferences from Local/Session Storage
  loadPreferences();

  // Initialize form dirty tracking
  initFormDirtyTracking();
});

// ==========================================
// 1. MOBILE MENU TOGGLE
// ==========================================
function initMobileMenu() {
  const menuToggle = document.querySelector('.menu-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (menuToggle && navLinks) {
    menuToggle.addEventListener('click', () => {
      navLinks.classList.toggle('active');
      // Simple rotation effect on burger bars
      menuToggle.classList.toggle('open');
    });

    // Close menu when clicking links
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('active');
        menuToggle.classList.remove('open');
      });
    });
  }
}

// ==========================================
// 2. PHONE VALIDATION (onblur)
// ==========================================
function validatePhoneNumber(input) {
  const value = input.value.trim();
  const phoneError = document.getElementById('phoneError');
  
  // Basic regex for exactly 10 digits
  const phonePattern = /^\d{10}$/;

  if (value === "") {
    phoneError.textContent = "Phone number is required.";
    input.style.borderColor = "var(--accent-color)";
    return false;
  } else if (!phonePattern.test(value)) {
    phoneError.textContent = "Please enter a valid 10-digit phone number (digits only).";
    input.style.borderColor = "var(--accent-color)";
    return false;
  } else {
    phoneError.textContent = "";
    input.style.borderColor = "var(--success-color)";
    return true;
  }
}

// ==========================================
// 3. EVENT FEE DISPLAY (onchange on dropdown)
// ==========================================
const eventFees = {
  concert: { name: "Annual Sunset Symphony", fee: "$15" },
  food: { name: "Food Truck Fiesta", fee: "Free" },
  art: { name: "Modern Art Expo", fee: "$10" },
  run: { name: "Run for Charity", fee: "$5" },
  tree: { name: "Tree Planting Campaign", fee: "Free" },
  movie: { name: "Outdoor Movie Night", fee: "$5" }
};

function handleEventTypeChange(val) {
  const feeDisplay = document.getElementById('feeDisplay');
  
  if (eventFees[val]) {
    const feeInfo = eventFees[val];
    feeDisplay.textContent = `Event Fee: ${feeInfo.fee}`;
    
    // Save selection immediately into sessionStorage for quick retrieval during session
    sessionStorage.setItem('currentSelectedEvent', val);
    
    // Save to localStorage for persistent preference storage as required
    localStorage.setItem('preferredEventType', val);
  } else {
    feeDisplay.textContent = "Select an event to view fee";
  }
}

// Quick helper to pre-select event type when clicking event card links
function setEventPreference(typeCode) {
  const dropdown = document.getElementById('regEventType');
  if (dropdown) {
    dropdown.value = typeCode;
    handleEventTypeChange(typeCode);
  }
}

// ==========================================
// 4. IMAGE ENLARGE LIGHTBOX (ondblclick)
// ==========================================
function enlargeImage(imgElement) {
  const modal = document.getElementById('lightboxModal');
  const modalImg = document.getElementById('lightboxImg');
  const captionText = document.getElementById('lightboxCaption');

  if (modal && modalImg) {
    modal.style.display = "flex";
    modalImg.src = imgElement.src;
    captionText.textContent = imgElement.title || imgElement.alt;
  }
}

function closeLightbox() {
  const modal = document.getElementById('lightboxModal');
  if (modal) {
    modal.style.display = "none";
  }
}

// Close lightbox on Escape key
document.addEventListener('keydown', (e) => {
  if (e.key === "Escape") {
    closeLightbox();
  }
});

// ==========================================
// 5. CHARACTER COUNTER (Keyboard events in textarea)
// ==========================================
function updateCharCount(textarea) {
  const max = textarea.getAttribute('maxlength') || 250;
  const len = textarea.value.length;
  const counterSpan = document.getElementById('charCount');
  
  if (counterSpan) {
    counterSpan.textContent = len;
    
    // Add visual warning color if close to limit
    if (len >= max - 20) {
      counterSpan.style.color = "var(--accent-color)";
      counterSpan.style.fontWeight = "bold";
    } else {
      counterSpan.style.color = "var(--text-muted)";
      counterSpan.style.fontWeight = "normal";
    }
  }
}

// ==========================================
// 6. VIDEO PROMO NOTIFICATION (oncanplay)
// ==========================================
function videoLoadedNotification() {
  const videoToast = document.getElementById('videoAlert');
  if (videoToast) {
    videoToast.classList.add('show');
    // Hide toast after 4 seconds automatically
    setTimeout(() => {
      videoToast.classList.remove('show');
    }, 4000);
  }
}

// ==========================================
// 7. BEFORE UNLOAD WARNING (onbeforeunload)
// ==========================================
let isFormDirty = false;

function initFormDirtyTracking() {
  const formInputs = document.querySelectorAll('#eventRegForm input, #eventRegForm select, #eventRegForm textarea');
  
  formInputs.forEach(input => {
    input.addEventListener('change', () => {
      isFormDirty = true;
    });
    input.addEventListener('input', () => {
      isFormDirty = true;
    });
  });
}

// Intercept window unload and warn user
window.onbeforeunload = function(e) {
  if (isFormDirty) {
    const warningMsg = "You have unsaved form inputs. If you leave, your details will be lost.";
    e.returnValue = warningMsg; // Standard browser behavior
    return warningMsg;
  }
};

// ==========================================
// 8. STORAGE PREFERENCES (localStorage / sessionStorage)
// ==========================================
function loadPreferences() {
  const preferredType = localStorage.getItem('preferredEventType');
  const sessionActiveEvent = sessionStorage.getItem('currentSelectedEvent');
  
  // Decide selection: session takes priority if set, otherwise persistent localStorage
  const targetPref = sessionActiveEvent || preferredType;

  if (targetPref) {
    const dropdown = document.getElementById('regEventType');
    if (dropdown) {
      dropdown.value = targetPref;
      handleEventTypeChange(targetPref);
    }
  }
}

function clearSavedPreferences() {
  // Clear storage values as requested
  localStorage.removeItem('preferredEventType');
  sessionStorage.removeItem('currentSelectedEvent');
  
  // Reset form elements
  const form = document.getElementById('eventRegForm');
  if (form) {
    form.reset();
    isFormDirty = false;
  }
  
  // Reset outputs
  document.getElementById('feeDisplay').textContent = "Select an event to view fee";
  document.getElementById('charCount').textContent = "0";
  document.getElementById('phoneError').textContent = "";
  document.getElementById('regName').style.borderColor = "var(--border-color)";
  document.getElementById('regPhone').style.borderColor = "var(--border-color)";
  
  alert("Preferences and session storage have been successfully cleared.");
}

// ==========================================
// 9. FORM SUBMIT CONFIRMATION
// ==========================================
function handleRegistrationSubmit(event) {
  event.preventDefault(); // Stop page reload

  const nameInput = document.getElementById('regName');
  const emailInput = document.getElementById('regEmail');
  const phoneInput = document.getElementById('regPhone');
  const dateInput = document.getElementById('regDate');
  const eventSelect = document.getElementById('regEventType');
  const messageInput = document.getElementById('regMessage');

  // Validate fields
  const isPhoneValid = validatePhoneNumber(phoneInput);
  if (!isPhoneValid) {
    phoneInput.focus();
    return;
  }

  // Retrieve select info
  const selectedCode = eventSelect.value;
  const eventInfo = eventFees[selectedCode];
  
  // Form submission details
  const ticketId = "TKT-" + Math.floor(100000 + Math.random() * 900000);
  const confirmationBox = document.getElementById('regConfirmationBox');
  const detailsDiv = document.getElementById('confirmationDetails');

  if (confirmationBox && detailsDiv) {
    detailsDiv.innerHTML = `
      <p>Thank you <strong>${escapeHTML(nameInput.value)}</strong>! Your ticket is confirmed.</p>
      <ul>
        <li><strong>Ticket ID:</strong> ${ticketId}</li>
        <li><strong>Event Name:</strong> ${eventInfo.name}</li>
        <li><strong>Date:</strong> ${dateInput.value}</li>
        <li><strong>Assigned Email:</strong> ${escapeHTML(emailInput.value)}</li>
        <li><strong>Registered Phone:</strong> ${phoneInput.value}</li>
        <li><strong>Ticket Fee:</strong> ${eventInfo.fee}</li>
      </ul>
      <p style="margin-top: 10px; font-size: 0.9rem; color: #1d7065;">A barcode and entry pass details have been sent to your email.</p>
    `;
    
    confirmationBox.classList.remove('hidden-element');
    confirmationBox.scrollIntoView({ behavior: 'smooth' });

    // Mark form as clean since it's successfully submitted
    isFormDirty = false;
  }
}

// Simple HTML escaping helper for output safety
function escapeHTML(str) {
  return str.replace(/[&<>'"]/g, 
    tag => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;'
    }[tag] || tag)
  );
}

// ==========================================
// 10. GEOLOCATION (Find Nearby Events)
// ==========================================
// Mock list of municipal event locations for coordinate calculations
const civicVenues = [
  { name: "Central Park Lawn (Sunset Symphony)", latOffset: 0.005, lngOffset: -0.004 },
  { name: "Market Square (Food Truck Fiesta)", latOffset: -0.003, lngOffset: 0.006 },
  { name: "Civic Center Gallery (Modern Art Expo)", latOffset: 0.001, lngOffset: 0.002 },
  { name: "Broadway Avenue Track (Charity Run)", latOffset: 0.008, lngOffset: -0.001 }
];

function locateUserAndEvents() {
  const geoDetails = document.getElementById('geoDetails');
  const geoError = document.getElementById('geoError');
  const latSpan = document.getElementById('geoLat');
  const lngSpan = document.getElementById('geoLng');
  const venueList = document.getElementById('venueList');

  // Reset errors and sections
  geoError.classList.add('hidden-element');
  geoError.textContent = "";

  if (!navigator.geolocation) {
    geoError.textContent = "❌ Geolocation is not supported by your browser.";
    geoError.classList.remove('hidden-element');
    return;
  }

  // Geolocation options: high accuracy, 10s timeout, no cache
  const geoOptions = {
    enableHighAccuracy: true,
    timeout: 10000,
    maximumAge: 0
  };

  navigator.geolocation.getCurrentPosition(
    (position) => {
      const lat = position.coords.latitude;
      const lng = position.coords.longitude;

      // Update text outputs
      latSpan.textContent = lat.toFixed(6);
      lngSpan.textContent = lng.toFixed(6);

      // Clear previous list
      venueList.innerHTML = "";

      // Populate venues with calculated mock distances based on GPS coordinates
      civicVenues.forEach(venue => {
        // Calculate mock distances in meters (rough projection)
        const mockDist = Math.round(
          Math.sqrt(Math.pow(venue.latOffset * 111320, 2) + Math.pow(venue.lngOffset * 111320, 2))
        );
        
        const li = document.createElement('li');
        li.innerHTML = `📍 <strong>${venue.name}</strong> - approximately <strong>${mockDist} meters</strong> away from your coordinates.`;
        venueList.appendChild(li);
      });

      // Show details
      geoDetails.classList.remove('hidden-element');
      geoDetails.scrollIntoView({ behavior: 'smooth' });
    },
    (error) => {
      geoDetails.classList.add('hidden-element');
      geoError.classList.remove('hidden-element');
      
      // Catch specific geolocation errors as required by item 10
      switch (error.code) {
        case error.PERMISSION_DENIED:
          geoError.textContent = "❌ Permission Denied: Please enable browser GPS permissions for this page.";
          break;
        case error.POSITION_UNAVAILABLE:
          geoError.textContent = "❌ Position Unavailable: Your device's GPS signal is currently offline or unreachable.";
          break;
        case error.TIMEOUT:
          geoError.textContent = "❌ Timeout: The request to retrieve GPS coordinates took too long and timed out.";
          break;
        default:
          geoError.textContent = `❌ Geolocation Error: ${error.message}`;
          break;
      }
    },
    geoOptions
  );
}

// ==========================================
// 11. FEEDBACK FORM HANDLER
// ==========================================
function handleFeedbackSubmit(event) {
  event.preventDefault();
  const feedbackBox = document.getElementById('feedbackConfirmation');
  const name = document.getElementById('feedbackName').value || "Anonymous";

  if (feedbackBox) {
    feedbackBox.innerHTML = `<p>🎉 Thank you, <strong>${escapeHTML(name)}</strong>! Your feedback rating has been sent directly to the Municipal Event Board.</p>`;
    feedbackBox.classList.remove('hidden-element');
    document.getElementById('feedbackForm').reset();
  }
}
